// pages/douban/splash.js
Page({

  /**
   * Page initial data
   */
  data: {
      subjects: [{
        id: 1,
        image: "../../image/large1.jpeg"
      }, {
        id: 2,
        image: "../../image/large2.jpg"
      }, {
        id: 3,
        image: "../../image/large3.jpg"
      }],
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {
/*    
    let app = getApp()
        app.request("https://api.rixingyike.com/doubanapiv2/movie/coming_soon?start=0&count=3").then(
          data => {
            this.setData({subjects: data.subjects})
          }
        )
*/
        wx.setStorage({
          key: 'has_shown_splash',
          data: true
        })
  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})