// pages/liaobo/list.js
Page({

  /**
   * Page initial data
   */
  data: {
      type: 'in_theaters',
      page: 1,
      size: 20,
      total: 1,
      movies: [],
      collections: [{
        id: 1,
        title: '朱熹书翰文稿  卷（局部）',
        image: '../../image/calligraphy.jpg',
        dynasty: '宋代',
        category: '书法作品',
        detail: '朱熹的书法风格具有典雅雍容、冲和不迫的贵族气息。他的书翰作品用笔老练精到、一丝不苟；提按有致，笔画沉实，无浮夸轻佻之习。但同时他又十分重视节奏的变化，使之处在一种极为和谐自然的状态之中，他徐徐写来，放纵而不拘谨、严谨而又洒脱，变化而有秩序，中矩而不呆板，秀媚而不取巧，他力求实践他自己提出的『动静无端，阴阳无始』的博大宽容的意境。他的此本书翰作品由两件作品组成，前一件用笔以篆为主，圆多于方；第二件作品则时见隶笔，以方见长，但两件作品都是字距密集，行距宽松，强调书写之势的一泻而下，用笔用墨之精熟令人拍案叫绝。其风格显得老辣苍茫，由于其单个字以取横势居多，故纵势则以字顶字来解决，这也不失为一法。杨仁恺认为此件作品『意致苍郁、沉深古雅』可谓的论。'
    }, {
      id: 2,
      title: '辽道宗皇帝碑志',
      image: '../../image/stone.jpg',
      dynasty: '辽代',
      category: '碑志',
      detail: '辽道宗耶律洪基（1032年9月14日－1101年2月12日），字涅邻，小字查刺，辽兴宗耶律宗真长子，母为仁懿皇后萧挞里 [1]  ，辽朝第八位皇帝。<br>\
重熙二十四年（1055年）继帝位，改元清宁。继位后奉兴宗弟耶律重元为皇太叔，加号天下兵马大元帅。清宁九年（1063年），派耶律仁先、耶律乙辛等平重元之乱。咸雍二年（1066），改国号为大辽（983年时辽改称契丹）。此后耶律乙辛擅权，直至大康七年（1081年）废黜耶律乙辛及其党羽。寿昌七年（1101年）正月，耶律洪基因病崩逝，终年七十岁。谥号仁圣大孝文皇帝，庙号道宗。六月，与宣懿皇后萧观音合葬庆陵。'
        }, {
          id: 3,
          title: '钧窑天青窑变釉兽耳衔环三足炉',
          image: '../../image/ceramics1.jpg',
          dynasty: '宋代',
          category: '陶瓷',
          detail: '钧窑天青窑变釉兽耳衔环三足炉 ：出自北宋（960-1279） 规格：高17.7、腹径20、口径17.9厘米.'
        }, {
          id: 4,
          title: '邢窑白瓷矮身横梁鸡冠壶',
          image: '../../image/ceramics2.jpg',
          dynasty: '晚唐',
          category: '陶瓷',
          detail: '邢窑白瓷矮身横梁鸡冠壶<br>\
                   晚唐至五代（618-960）<br>\
                   高17、口径2.9、腹径15.3X15.1厘米.'
        }, {
          id: 5,
          title: '燕王职戈',
          image: '../../image/bronze1.jpg',
          dynasty: '战国晚期（前3世纪）',
          category: '青铜器',
          detail: '通长27.2厘米<br>\
辽宁省北票县东官营子出土<br>\
形体大，中部有隆起的脊，脊旁有凹形血槽，胡作三弧线，阑内三穿，直内一穿，内铸虎纹，胡上铸铭文：“郾王职乍御司马”。为燕王作，为其御司寇所用之兵器。器精美而文字史料价值极高。'
        }, {
          id: 6,
          title: '玉猪龙',
          image: '../../image/jade1.jpg',
          dynasty: '红山文化（距今6000—5000年前）',
          category: '玉器',
          detail: '高15、宽10.2、厚3.8厘米<br>\
辽宁省建平县采集<br>\
      玉猪龙是红山文化玉器的代表作，这件是已知红山文化玉猪龙中形体较大，形制最规整的一件。白色蛇纹叶岩，肥首大耳，圆睛、吻部前突，口微张，獠牙外露，体蜷曲如环，扁圆厚重，背部有一穿孔。玉猪龙明确出土于墓葬中，而且成对佩戴在墓主人胸前，是社会地位、等级、权力的象征，是按照一定规格制成的原始“礼器”。'
        }, {
          id: 7,
          title: '铜鎏金大威德金刚',
          image: '../../image/buddha1.jpg',
          dynasty: '清代（乾隆）',
          category: '佛像',
          detail: '高23厘米<br>\
      此尊为九头三十四臂，九头分三层排列，正面为牛头，牛角粗大，血盆大口，头戴五骷髅冠；最上一头，为如来相，象征着他是阿弥陀佛化身而来。最下面七头，头顶红发上竖，象征忿怒。上身饰璎珞，下身围虎皮，顶挂五十人头骨串。主二臂抱明妃，其余手伸向两边，诸手皆持法器，铃、杵、刀、剑、弓、箭、瓶、索子、钩、戟、伞、盖、骷髅等兵器，各有寓意。有十六条腿，皆左展姿站立，左右脚分别踩八种人、兽和禽。明妃罗浪杂娃坐在主尊怀中，右手持月刀，左手持人心，左腿勾在主尊腰间，右脚踩飞禽。下为单层覆莲座。此尊形象复杂，面目手足众多，但布局简洁明了，线条一丝不苟。台座上刻“大清乾隆御制”楷书款'
    }]
  },

  retrieve: function () {
    let app = getApp()
    let start = (this.data.page - 1) * this.data.size

    // console.log('Into retrieve function...')

    wx.showLoading({
      title: '加载中',
    })

    return app.request(`https://api.rixingyike.com/doubanapiv2/movie/${this.data.type}?start=${start}&count=${this.data.size}`)
              .then(res => {
                if (res.subjects.length) {
                  let movies = this.data.movies.concat(res.subjects)
                  this.setData({movies: movies, total: res.total})

//                  wx.setNavigationBarTitle({
//                    title: res.title,
//                  })

                  console.log(movies)
                }
              }).catch(err => {
                console.error(err)
              }).finally( () => {
                wx.hideLoading()
              })
  },

  loadMorePage: function () {
    if (this.data.page > this.data.total) return

    this.data.page ++
    this.retrieveData()
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {
    this.data.type = options.type || this.data.type
    //this.retrieve()
  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {
  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})