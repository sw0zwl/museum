// pages/liaobo/indoor.js
Page({

  /**
   * Page initial data
   */
  data: {
    position: ''
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {
    var that = this;

    //监测蓝牙状态的改变
    wx.onBluetoothAdapterStateChange(function (res) {
      if (res.available) {//如果用户打开蓝牙，开始搜索IBeacon
        console.log('try to search beacon')
        searchBeacon();
      }
      else
      {
        console.log('beacon is not available')        
      }
    })

    //搜索beacons
    searchBeacon();

    //搜索函数
    function searchBeacon() {
      //检测蓝牙状态
      console.log('try to open bluetooth adapter')
      wx.openBluetoothAdapter({
        success: function (res) {//蓝牙状态：打开
        console.log('try to start beacon discovery')
          wx.startBeaconDiscovery({//开始搜索附近的iBeacon设备
            uuids: ['01122334-4556-6778-899a-abbccddeeff0'],//参数uuid
            success: function (res) {
              console.log('try to onBeaconUpdate')
              wx.onBeaconUpdate(function (res) {//监听 iBeacon 设备的更新事件  
                //封装请求数据 
                var beacons = res.beacons;
                var reqContent = {};
                var bleArray = [];
                for (var i = 0; i < beacons.length; i++) {
                  var bleObj = {};
                  bleObj.distance = beacons[i].accuracy;
                  bleObj.rssi = beacons[i].rssi;
                  bleObj.mac = beacons[i].major + ":" + beacons[i].minor;
                  bleArray.push(bleObj);
                }
                reqContent.ble = bleArray;
                //请求后台向redis插入数据
                console.log('try to push data to end back')
                redisSave(reqContent);
              });
            },
            fail: function (res) {
              //先关闭搜索再重新开启搜索,这一步操作是防止重复wx.startBeaconDiscovery导致失败
              console.log('startBeaconDiscovery fail')
              stopSearchBeacom();
            }
          })
        },
        fail: function (res) {//蓝牙状态：关闭
          console.log('openBluetoothAdapter fail')
          wx.showToast({ title: "请打开蓝牙", icon: "none", duration: 2000 })
        }
      })
    }

    function redisSave(reqContent) {
      // position = JSON.stringify(reqContent)
      console.log(JSON.stringify(reqContent))
/*      
      wx.request({
        url: "https://map.intmote.com/LocateServer/location.action",
        data: JSON.stringify(reqContent),
        method: 'POST',
        header: {
          'Content-type': 'application/json'
        },
        success: function (res) {
          // wx.showToast({ title: "seccess" })
        },
        fail: function (res) {
          // wx.showToast({ title: "1" })
        }
      });
*/      
    }
    
    //关闭成功后开启搜索
    function stopSearchBeacom() {
      console.log('into stop search beacon')
      wx.stopBeaconDiscovery({
        success: function () {
          searchBeacon();
        }
      })
    }    
  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})