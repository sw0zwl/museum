// pages/douban/index.js
Page({

  /**
   * Page initial data
   */
  data: {
    boards: [{
      key: 'in_theaters',
      images: {
        large: '../../image/large1.jpeg'
      }
    }, {
        key: 'coming_soon',
        images: {
          large: '../../image/large2.jpg'
        }
    }, {
        key: 'top250',
        images: {
          large: '../../image/large3.jpg'
        }
    }],
    notifies: [{
      key: 0x01,
      title: '国宝荟萃难得一见 展示辽宁历史文化'
    }, {
      key: 0x02,
      title: '[又见江山]精品文物展今日开幕'
      }, {
      key: 0x03,        
      title: '[又见大唐]展展出文物介绍（三）'
      }, {
      key: 0x04,        
      title: '[红]动一时系列教育活动上线了'
      }, {
      key: 0x05,        
      title: '辽博讲堂讲座预告'
    }]
  },

  retrieveData() {
    let app = getApp()

    var promises = this.data.boards.map(function(board) {
      return app.request(`https://api.rixingyike.com/doubanapiv2/movie/${board.key}?start=0&count=10`)
        .then(function(d) {
          if (!d) return board

          // console.log('into retrieve data....')

          board.title = d.title
          board.movies = d.subjects

          return board
        }).catch(err => console.log(err))
    })

    return app.promise.all(promises).then(boards => {
      if (!boards || !boards.length) return

      this.setData({
        boards: boards,
        loading: false
      })
    })
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function(options) {
    //    this.retrieveData()

    wx.getStorage({
      key: 'has_shown_splash',
      success: res => {
        //this.retrieveData()
        this.setData({
          loading: false
        })

      },
/*
      fail: err => {
        wx.redirectTo({
          url: '/pages/liaobo/splash',
        })
      }
*/      
    })
  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function() {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function() {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function() {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function() {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function() {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function() {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function() {

  }
})