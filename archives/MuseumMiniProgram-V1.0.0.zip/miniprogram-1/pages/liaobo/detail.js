// pages/liaobo/detail.js
Page({

  /**
   * Page initial data
   */
  data: {
    articles: [
      {
        title: '又见大唐补习班',
        author: '王二小',
        date: '2019-10-22',
        image: '../../image/large1.jpeg',
        content: '<p>活动时间：2019年10月13日下午<br>\
                  活动地点：辽宁省博物馆展厅三楼培训教室<br>\
                  报名方式：现场报名，即报即参加<br><br>\
                  打卡“大唐补习班”，您心动了吗？<br><br>\
                  <h3>重要提示：</h3>\
                  “大唐补习班”全程公益，不收取任何费用。</p>'
      },
    ]
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})