//logs.js
const util = require('../../utils/util.js')

Page({
  data: {
    logs: [],
    notifies: [{
      key: 0x01,
      title: '我关注的藏品'
    }, {
      key: 0x02,
      title: '我要提意见建议'
    }, {
      key: 0x03,
      title: '关于我们'
    }]
  },
  onLoad: function () {
    this.setData({
      logs: (wx.getStorageSync('logs') || []).map(log => {
        return util.formatTime(new Date(log))
      })
    })
  }
})
